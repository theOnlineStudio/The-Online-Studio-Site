<?php include($_SERVER['DOCUMENT_ROOT'].'/_inc/header.php') ?>
	<div id="page">
		<div id="inner">
		

	<div id="work">
	<!-- intro -->
		<div id="intro">
			<h2>Over the past 5 years we have worked on all manner of digital projects including <em>websites</em>, <em>microsites</em>, <em>facebook</em> and <em>mobile apps</em>, as well as <em>banners</em> and <em>html emails</em>.

				We <em>white label</em> for many of our clients meaning we are unable to talk about much of the great work we do.  If you would like to see more please <a href="/contact">get in touch</a>. </h2>
		</div>
		<!-- slider -->
		<div id="pullout">
			<?php include($_SERVER['DOCUMENT_ROOT'].'/_inc/slideshow.php') ?>	
        </div>
	<!--  4 cols -->
		<div id="threeCol">
		
		<div class="row">
						<div>
						<a class="fancybox fancybox.ajax" href="/_work/w-sky.html" onclick="return false;"><h3>CMS Website</h3>
						<img src="/_work/_img/_thumb/w-sky.jpg" alt="o-moo"/></a>
					</div>
					<div>
						<a class="fancybox fancybox.ajax" href="/_work/r-mazda.html" onclick="return false;"><h3>Rich Media</h3>
						<img src="/_work/_img/_thumb/r-mazda.jpg" alt="o-microsoft"/></a>
					</div>
					<div>
						<a class="fancybox fancybox.ajax" href="/_work/r-airNz.html" title="we developed an online shop for The Cupcake bakehouse"><h3>Rich media</h3>
						<img src="/_work/_img/_thumb/r-airNz.jpg" alt="s-microsoft"/></a>

					</div>
			</div>
			<div class="row">
					<div>
						<a class="fancybox fancybox.ajax" href="/_work/f-mazda.html" title="Mazda Connect Racing"><h3>Facebook App</h3>
						<img src="/_work/_img/_thumb/f-mazda.jpg" alt="Mazda"/></a>
					</div>
					<div>
						<a class="fancybox fancybox.ajax" href="/_work/f-iceWatch.html" title="Ice watches - Pick your perfect arm candy"><h3>Facebook App</h3>
						<img src="/_work/_img/_thumb/f-iceWatch.jpg" alt="Ice Watch "/></a>
					</div>
				<div>
						<a class="fancybox fancybox.ajax" href="/_work/o-moo.html" title="Microsoft - Standard Banners"><h3>Standard Banners</h3>
						<img src="/_work/_img/_thumb/o-moo.jpg" alt="e-bertolli"/></a>
					</div>
			</div>
			
		<div class="row">
		<div>
						<a class="fancybox fancybox.ajax" href="/_work/e-bertolli.html" title="Microsoft - Standard Banners"><h3>HTML email</h3>
						<img src="/_work/_img/_thumb/e-bertolli.jpg" alt="r-airNz"/></a>
					</div>
					<div>
						<a class="fancybox fancybox.ajax" href="/_work/w-renault.html" title="Renault - Competition microsite"><h3>Competition microsite</h3>
						<img src="/_work/_img/_thumb/w-renault.jpg" alt="r-airNz"/></a>
					</div>
					
					<div>
						<a class="fancybox fancybox.ajax" href="/_work/w-ellas.html" onclick="return false;"><h3>E-commerce website</h3>
						<img src="/_work/_img/_thumb/w-ellas.jpg" alt="w-ellas"/></a>
					</div>
			
					
			</div>
			<div class="row">
					<div class="logos">
					<h3>Some of the great brands we've worked on</h3>
					<img src="/_img/logos/Argos_logo.jpg" alt="Argos" />
					<img src="/_img/logos/t_mobile.jpg" alt="T Mobile" />
					<img src="/_img/logos/JP_Morgan.jpg" alt="JP Morgan" />
					<img src="/_img/logos/Douwe_Egberts_logo.jpg" alt="Douwe Egberts" />
					<img src="/_img/logos/Duracell_logo.jpg" alt="Duracell" />
					<img src="/_img/logos/Sky_logo.jpg" alt="Sky" />
					<img src="/_img/logos/Colgate_logo.jpg" alt="Colgate" />
					<img src="/_img/logos/boots.jpg" alt="Boots" />
					<img src="/_img/logos/aa.jpg" alt="AA" />
					<img src="/_img/logos/Marks_and_Spencer.jpg" alt="Marks and Spencer" />
					<img src="/_img/logos/three.jpg" alt="three" />
					<img src="/_img/logos/betfair.jpg" alt="Betfair" />
					<img src="/_img/logos/Orange.jpg" alt="Orange" />
					<img src="/_img/logos/air_new_zealand.jpg" alt="Air New Zealand" />
					<img src="/_img/logos/virgin_media.jpg" alt="Virgin Media" />
					<img src="/_img/logos/Vodafone_logo.jpg" alt="Vodafone" />
					<img src="/_img/logos/Accenture.jpg" alt="Accenture" />
					<img src="/_img/logos/blackberry.jpg" alt="Blackberry" />
					<img src="/_img/logos/Bensons.jpg" alt="Bensons" />
					<img src="/_img/logos/htc.jpg" alt="HTC" />
					<img src="/_img/logos/Microsoft_logo.jpg" alt="Microsoft" />
					<img src="/_img/logos/m_tv.jpg" alt="MTV" />
					<img src="/_img/logos/Auto_Trader.jpg" alt="Auto_Trader" />
					<img src="/_img/logos/bp.jpg" alt="bp" />
					<img src="/_img/logos/Direct_line.jpg" alt="Direct_line" />
					<img src="/_img/logos/doveSpa.jpg" alt="doveSpa" />
					<img src="/_img/logos/Hellmanns.jpg" alt="Hellmanns" />
					<img src="/_img/logos/mazda.jpg" alt="mazda" />
					<img src="/_img/logos/national-lottery.jpg" alt="National Lottery" width="144" height="150" />
					<img src="/_img/logos/Nokia_logo.jpg" alt="Nokia" />
					<img src="/_img/logos/sony.jpg" alt="Sony" />
					<img src="/_img/logos/which.jpg" alt="Which" />
					</div>
		</div>
		
		
		
		
		
		
		
		</div>
	</div>			
</div>				
</div>
<?php include($_SERVER['DOCUMENT_ROOT'].'/_inc/footer.php') ?>
