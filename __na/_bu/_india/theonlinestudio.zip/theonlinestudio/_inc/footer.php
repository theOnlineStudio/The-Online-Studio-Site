	</div>
</div>
<div id="footer">
	<div>
		<div class="contact">
				<h4>Contact Us</h4>
				<p>	<a href="http://facebook.com/theonlinestudio" target="_blank"><img src="/_img/site/nav_facebook2.png" alt="Facebook"></a>
			<a href="https://twitter.com/theonlinestudio" target="_blank"><img src="/_img/site/nav_twitter2.png" alt="Twitter"></a>
			<a href="http://gplus.to/theonlinestudio" target="_blank"><img src="/_img/site/nav_google-plus2.png" alt="Google Plus"></a>The Online Studio <br/>83 Crawford Street<br/>London  W1H 2HB<br/>020 7723 4703<br/>theonlinestudio.co.uk<br/><a href="mailto:hello@theonlinestudio.co.uk">hello@theonlinestudio.co.uk</a>
			<br/>		
		</p>
			</div>
			<div class="testamonials">
			<h4>What people are saying about The Online studio</h4>
							<?php include($_SERVER['DOCUMENT_ROOT'].'/_inc/testamonials.php') ?>	

			</div>
	
</div>
<script src="/_js/jquery-1.8.2.min.js"></script>
<!-- include Cycle plugin -->
<script src="/_js/jquery.fancybox.pack.js"></script>

<script src="/_js/custom.js"></script>
<script type="text/javascript" src="http://cloud.github.com/downloads/malsup/cycle/jquery.cycle.all.latest.js"></script>
<script src="//ajax.googleapis.com/ajax/libs/swfobject/2.2/swfobject.js"></script>
<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAZft_nDQareNZf9krYptSJBLjMbdmTZA8&sensor=true"> </script>
</body>
</html>