var time = 500;
var currUrl;
$().ready(function() {
	init()
});
 
function init(){	

$('#highlight').show();
	
	$('#header a').click(function(e) {
		e.preventDefault();
		href = $(this).attr("href");
		hrefNoSlash = href.replace(/\//g,'');
		loadContent(hrefNoSlash);
		history.pushState('', 'New URL: '+href, href);
		currUrl = hrefNoSlash;
	
	});
	
		// THIS EVENT MAKES SURE THAT THE BACK/FORWARD BUTTONS WORK AS WELL
		window.onpopstate = function(event) {
		//console.log("pathname: "+location.pathname);
		var pageName = location.pathname;
		pageNoSlash = pageName.replace(/\//g,'');
		loadContent(pageNoSlash); 
	
		///PASS IN INDEX
	};
	
	 x=$("#whatNav").position();
	// alert("Top: " + x.top + " Left: " + x.left);
	
	//alert('hello' + $('#whatNav').parent());

	function writeTitle(url){
	//console.log (url);
		 switch (url){
		  	case "": 			document.title = 'The Online Studio | Welcome'; 					break;
		 	case "what": 		document.title = 'The Online Studio | What we do';	 				break;
		 	case "why": 		document.title = 'The Online Studio | Why us?';	 				break;
		 	case "who": 		document.title = 'The Online Studio | Who we are';	 				break;
		 	case "work": 		document.title = 'The Online Studio | Our work';	 				break;
		 	case "contact": 	document.title = 'The Online Studio | Get in touch';				break;	 
		 	case "clients": 	document.title = 'The Online Studio | Clients';		 				break;	 
		 }
	}
	function navSlider(whatPage){
		switch (whatPage){
			case "": 		$('#highlight').animate({'right' : '550px', 'width':'0px'},time, function(){$('#homeNav').addClass('active')}); removeActive(); 	break;
			case "what": 	$('#highlight').animate({'right' : '442px', 'width':'83px'},time, function(){$('#whatNav').addClass('active')}); removeActive();	break;
			case "why": 	$('#highlight').animate({'right' : '375px', 'width':'65px'},time, function(){$('#whyNav').addClass('active')}); removeActive();		break;
			case "work":	$('#highlight').animate({'right' : '300px', 'width':'72px'},time, function(){$('#workNav').addClass('active')}); removeActive();	break;
			case "who":  	$('#highlight').animate({'right' : '215px', 'width':'82px'},time, function(){$('#whoNav').addClass('active')}); removeActive();		break;
			case "contact":	$('#highlight').animate({'right' : '149px', 'width':'64px'},time, function(){$('#contactNav').addClass('active')}); removeActive();	break;
		}
	}
	
	function loadContent(url){
	//console.log("url = " + url + " & currUrl = " + currUrl);
		if(url !='' && url != currUrl){
			$('#page').fadeOut('slow', function() {$('#page').load('/'+url+' #inner', function() {inPage(url);$('#page').fadeIn('slow').delay(600); writeTitle(url);})});
			navSlider(url);
		}
		if(url ==''){
			$('#page').load('/'+url+' #inner', function() {inPage();});  writeTitle(url);
			$('.aslideshow').toggleClass('slideshow');

			navSlider(url);
		}
	}
	
	function inPage(page){
	//alert(page);
		$('.fancybox').fancybox();
		 $('.slideshow').cycle({
			 fx:	'bounce', 
			 sync:  1, 
			 pause:	1,
			 random: 1,
			numeric: true,
			timeout: 7000,

    	});
    	if (page=='contact'){
    	makeMap();
 		}
		$('#page a').click(function(e) {
			e.preventDefault();
			href = $(this).attr("href");
			hrefNoSlash = href.replace(/\//g,'');
			loadContent(hrefNoSlash);
			history.pushState('', 'New URL: '+href, href);
			currUrl = hrefNoSlash;
	
		});
	
		// THIS EVENT MAKES SURE THAT THE BACK/FORWARD BUTTONS WORK AS WELL
		window.onpopstate = function(event) {
			var pageName = location.pathname;
			pageNoSlash = pageName.replace(/\//g,'');
			loadContent(pageNoSlash); 
		};
	}
	
	function makeMap(){
		
        var mapOptions = {
          center: new google.maps.LatLng(51.51901, -0.16278),
          zoom: 16,
          mapTypeId: google.maps.MapTypeId.ROADMAP
        };
        var map = new google.maps.Map(document.getElementById("map_canvas"),
            mapOptions);
            var myLatLng = new google.maps.LatLng(51.51912, -0.16128);
            var beachMarker = new google.maps.Marker({
	        position: myLatLng,
	        map: map,
            icon: '/_img/site/us.png',
            shadow: '/_img/site/us-shadow.png',
            draggable:false,
            animation: google.maps.Animation.DROP
      });     
	}
	
	function removeActive(){
		//$("#homeNav").removeClass("active");
		$("#whatNav").removeClass("active");
		$("#whyNav").removeClass("active");
		$("#whoNav").removeClass("active");
		$("#workNav").removeClass("active");
		$("#contactNav").removeClass("active");
		$("#clientsNav").removeClass("active");
	}



}



