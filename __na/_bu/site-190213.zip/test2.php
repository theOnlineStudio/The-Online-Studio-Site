<?php include($_SERVER['DOCUMENT_ROOT'].'/_inc/header.php') ?>
<script>
		$('#slideshow').cycle({
    fx:    'scrollRight',
    delay: -1000
});</script>
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.5/jquery.min.js"></script>
<script type="text/javascript" src="http://malsup.github.com/chili-1.7.pack.js"></script>
<script type="text/javascript" src="http://malsup.github.com/jquery.cycle.all.js"></script>
<script type="text/javascript" src="http://malsup.github.com/jquery.easing.1.3.js"></script>

		
	<div id="slideshow">
            <div><p>We'll turn a quote around within the hour and get your work started within 24 hours Get in touch and put us to the test</p></div>
            <div><p>You only pay for the resource you use - we charge by the hour and not by the day Contact us for a quote ></p></div>
            <div><p>In house creative guardianship ensures projects are not churned out but are crafted until they meet our high standards Find out who we are ></p></div>
            <div><p>You can relax knowing all your work is passed through four rounds of quality assurance before it comes back to you See more reasons to use us > (This does not exist)</p></div>
            <div><img src="/_img/slider/05.gif" alt="01" width="764" height="250" /></div>
            <div><img src="/_img/slider/06.gif" alt="01" width="764" height="250" /></div>
            <div><img src="/_img/slider/07.gif" alt="01" width="764" height="250" /></div>
        </div>