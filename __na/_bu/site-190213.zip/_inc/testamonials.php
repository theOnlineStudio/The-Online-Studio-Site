<div class="slideshow">
		<p class="quote">The Online Studio have been working with us on production for over two years now. They are fast, efficient, friendly and always willing to offer suggestions or support in areas they feel could be improved. Their translation from a layout to a final build is faultless and I’ve never heard the words ‘that can’t be done’ without a good reason. I wouldn’t hesitate to recommend them to others.<br/><br/>
			<span class="title">Ryan Wylie | Creative Director | Cubo</span></p>

		<p class="quote">Thanks again for all your guys help on this. The turnaround was great and standards high as usual.<br/><br/>
			<span class="title">Phil Dabrowski | Senior Digital Producer | BBH</span></p>

		<p class="quote">I’ve used the team at Online for some very technical, multi-party projects. They’ve slotted seamlessly into my team taking problems as challenges, resolving them quickly and efficiently with smiles on their faces. I have every confidence jobs will get done well, on time and to budget. They’re a pleasure to work with. Win-win!<br/><br/>
			<span class="title">Jamie Cook | Creative Services Director | The Market Comms </span></p>
			
		<p class="quote">The Online Studio has been a great addition to our working partners.  Manisha, Anna and the whole team supply a quick, friendly and efficient service from supplying quotes to completing the job.  There is never an issue with capacity and we always get a quick turnaround. The addition of The Online Studio to our preferred partners has helped keep our freelancer budget in check as you get more banners for your money than having a freelancer onsite.<br/><br/>
			<span class="title">Glega Minaidis | Traffic Manager | Geronimo </span></p>

	<p class="quote">We’ve worked with The Online Studio on a wide range of digital projects.  The team are professional, responsive and committed to doing a good job for us. They have excellent digital knowledge and are always a pleasure to work with.<br/><br/>
			<span class="title">Frankie Laws | Director | Drew Frank </span></p>
			
		<p class="quote">We've worked with Manisha, Corin and the team at The Online Studio since we first opened our doors in Shoreditch, and it's been a delight from day one. As a start-up, you're always looking for value, but you expect to sacrifice reliability, responsiveness or creative craft to get it - that's never been the case with these guys. A pleasure at the start, and a pleasure today, on every level. <br/>
			<span class="title">Dan Shute | Managing Partner | Creature of London </span></p>


</div>
	
