<div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_US/all.js#xfbml=1";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>

<div class="social"><div class="fb-like" data-href="http://www.facebook.com/theonlinestudio" data-layout="box_count" data-send="true" data-width="60" data-show-faces="true" data-font="segoe ui"></div>


</div>